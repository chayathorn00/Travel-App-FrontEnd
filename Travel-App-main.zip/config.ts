export const BASE_URL = "http://192.168.1.121:3000";
export const LONGDO_MAP_API = "eafae1f0f4a433fc431f4d481e131b58";